let cart=JSON.parse(localStorage.getItem('sportshaqCart')||'[]');
function render(){let html='';let sub=0;cart.forEach(c=>{let m=menuItems.find(x=>x.id===c.id);sub+=m.price*c.qty;html+=`<div>${m.name} ₦${m.price} x ${c.qty} <button onclick='chg(${c.id},1)'>+</button><button onclick='chg(${c.id},-1)'>-</button></div>`});html+=`<h3>Subtotal: ₦${sub}</h3>`;document.getElementById('cart').innerHTML=html;}
function chg(id,d){let f=cart.find(x=>x.id===id);f.qty+=d;if(f.qty<=0)cart=cart.filter(x=>x.id!==id);localStorage.setItem('sportshaqCart',JSON.stringify(cart));render();}
render();
document.getElementById('checkoutForm').onsubmit=(e)=>{e.preventDefault();localStorage.setItem('lastOrder',document.getElementById('cart').innerHTML);window.location='confirmation.html';};