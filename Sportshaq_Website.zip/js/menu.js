let cart=JSON.parse(localStorage.getItem('sportshaqCart')||'[]');
function save(){localStorage.setItem('sportshaqCart',JSON.stringify(cart));document.getElementById('cartCount').textContent=cart.reduce((a,b)=>a+b.qty,0)}
document.getElementById('menu').innerHTML=menuItems.map(i=>`<div class='card'><img src='${i.image}'><h3>${i.name}</h3><p>₦${i.price}</p><button onclick='add(${i.id})'>Add to Cart</button></div>`).join('');
function add(id){const f=cart.find(x=>x.id===id);if(f)f.qty++;else cart.push({id,qty:1});save();}
save();