const menuItems=[
{id:1,name:'Jollof Rice',price:2500,category:'Rice & Swallow',image:'https://via.placeholder.com/300x200'},
{id:2,name:'Fried Rice',price:2800,category:'Rice & Swallow',image:'https://via.placeholder.com/300x200'},
{id:3,name:'Grilled Chicken',price:3000,category:'Chicken/Meat',image:'https://via.placeholder.com/300x200'},
{id:4,name:'Meat Pie',price:1000,category:'Pastries',image:'https://via.placeholder.com/300x200'},
{id:5,name:'Coke',price:500,category:'Drinks',image:'https://via.placeholder.com/300x200'},
{id:6,name:'Combo Meal',price:4500,category:'Combo Meals',image:'https://via.placeholder.com/300x200'}
];